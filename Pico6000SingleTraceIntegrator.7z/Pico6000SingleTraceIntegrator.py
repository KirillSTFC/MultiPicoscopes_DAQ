import ctypes 
from picosdk.ps6000 import ps6000 as ps
import numpy as np
from picosdk.functions import adc2mV, assert_pico_ok
from datetime import datetime

import matplotlib.pyplot as plt 
from scipy import integrate
#from scipy.signal import argrelmax

status = {}

chandle = ctypes.c_int16()          #holds PicoScope C id.

#Open PicoScope with ps6000OpenUnit() function
status["openunit"] = ps.ps6000OpenUnit(ctypes.byref(chandle), None)

assert_pico_ok(status["openunit"])
    
    
#########################################################
#########################################################
#########################################################
filename="pico_event_trace_.dat"
PulseIntegralsFilename = "Large_BGO-SiPM_pico_pulse_voltage_integrals.dat"
#########################################################
#########################################################
#########################################################



#Channel set up using ps60000SetChannel() function output assigned to list 'setChA in 'status' dictionary.

########################
########################
########################    
setch_Channel = 0            #sets channel to be assigned settings. B=1, C=2 etc.
setch_Enabled = 1            #enables channel
setch_Coupling = 2           #sets Pico coupling to 50ohm DC. AC = 0, (Mohm)DC = 1.
setch_Range = 5              #sets variable PicoScope voltage range to 50mV. 100mV = 3, 200mV = 4, etc.
########################
########################
########################


setch_Offset = 0             #sets analogue offet (leave alone)
setch_BandwidthLimiter = 0   #turns off bandwidth limiter. 1 = -3dB, limited to 25MHz.
    
status["setChA"] = ps.ps6000SetChannel(chandle, setch_Channel, setch_Enabled, setch_Coupling, setch_Range, setch_Offset, setch_BandwidthLimiter)
    
assert_pico_ok(status["setChA"])
    
    
#Trigger set up using ps6000SetSimpleTrigger() function assigned to 'trigger' in 'status' dictionary.

#################################
#################################
#################################    
settrig_Enabled = 1                  #enables trigger
settrig_SourceChannel = 0            #sets trigger source channel. B = 1, C = 2, etc.
settrig_Threshold = 5               #sets trigger threshold to approximate percentage fraction of range i.e. 10%. Can set negative threshold using negative percentage, i.e -10 = -10%
settrig_Direction = 2                #sets trigger direction to Rising Edge. Above = 0, Below = 1, Rising = 2, Falling = 3, Rising OR Falling = 4
settrig_AutoTrigger_ms = 10000        #For Trig. Mode: Auto. Number of milliseconds that device will wait if no trigger occurs
#################################
#################################
#################################


settrig_Delay = 0    
status["trigger"] = ps.ps6000SetSimpleTrigger(chandle, settrig_Enabled, settrig_SourceChannel, int(round(settrig_Threshold * 325.12,0)), settrig_Direction, settrig_Delay, settrig_AutoTrigger_ms)
    
assert_pico_ok(status["trigger"])
    
    
#setting number of samples before and after trigger

#########################
#########################
#########################
preTriggerSamples = 10
postTriggerSamples = 100
#########################
#########################
#########################

maxSamples = preTriggerSamples + postTriggerSamples
    
    
#setting PicoScope time base settings using ps6000GetTimebase2() function assigned to 'Timebase' in 'status' dictionary.
    
                #setting sampling rate by adjusting settimebase_SamplingInterval variable
    
                #formula for 0 < settimebase_SamplingInterval < 4 :
                #       real sampling interval = [2^(settimebase_SamplingInterval)]/(5 billion)
    
                #for 5 < settimebase_SamplingInterval < [2^(32) - 1] :
                #       real sampling interval = (settimebase_SamplingInterval - 4)/ 156,250,000
    
                #i.e.
                ###################################################################
                # settimebase_SamplingInterval   ---     real sampling interval   #
                ###################################################################
                #              0                 ---             200ps            #
                #              1                 ---             400ps            #
                #              2                 ---             800ps            #
                #              3                 ---             1.6ns            #
                #              4                 ---             3.2ns            #
                ###################################################################
                #              5                 ---             6.4ns            #
                #              ...               ---             ...              #
                #           2^(32) - 1           ---             6.87s            #
                ###################################################################


################################
################################
################################
settimebase_SamplingInterval = 10                            #see above table 
################################
################################
################################

           
settimebase_SampleNumber = maxSamples                        #sets sample number to previously defined maximum variable "maxSamples"
settimebase_ReturnedTimeInterval_ns = ctypes.c_float()       #this is a value output by the funtion
settimebase_Oversampling = 0                                 #used to average voltage over time. Set to 0 unless setting understood.
settimebase_ReturnedMaxSamples = ctypes.c_int32()            #output by function. Max no. of samples available on exit. 
settimebase_SegmentationIndex = 0                            #index of memory segment to use. 
    
status["Timebase"] = ps.ps6000GetTimebase2(chandle, settimebase_SamplingInterval, settimebase_SampleNumber, ctypes.byref(settimebase_ReturnedTimeInterval_ns), settimebase_Oversampling, ctypes.byref(settimebase_ReturnedMaxSamples), settimebase_SegmentationIndex)
    
assert_pico_ok(status["Timebase"])

###############
###############
###############
EventsNo = 5           # Number of pulses above trigger threshold recorded
###############
###############
###############


peakHeights = np.empty((EventsNo,1))                        #empty array to hold peak heights
pulseIntegrals = np.empty((EventsNo,1))                     #empty array to hold pulse integrals

pulses = 0    
while pulses<EventsNo:    

    # A function to collect a block of data using the ps6000RunBlock() function assigned to 'runBlock' in 'status' dictionary.
    
    runBlock_preTrigSamples = preTriggerSamples                         
    runBlock_postTrigSamples = postTriggerSamples
    runBlock_SamplingInterval = settimebase_SamplingInterval
    runBlock_Oversampling = 0
    runBlock_SamplingTime = None                                    #Output. Time in ms that the scope will spend collecting samples. Set to 'None' if unimportant
    runBlock_SegmentationIndex = 0                                  
    
    status["runBlock"] = ps.ps6000RunBlock(chandle, runBlock_preTrigSamples, runBlock_postTrigSamples, runBlock_SamplingInterval, runBlock_Oversampling, runBlock_SamplingTime, runBlock_SegmentationIndex, None, None)
    
    assert_pico_ok(status["runBlock"])
    
    
    # DOWNLOADING DATA TO COMPUTER MEMORY
    
    # Check that scope has finished collecting data using ps6000IsReady() function
    
    ready = ctypes.c_int16(0)
    check = ctypes.c_int16(0)
    
    while ready.value == check.value:
        status["isReady"] = ps.ps6000IsReady(chandle, ctypes.byref(ready))
        
    
    # Creating local buffers
        
    bufferAMax = (ctypes.c_int16 * maxSamples)()
    bufferAMin = (ctypes.c_int16 * maxSamples)()
    
    
    # Assign data to the local buffer variables
    
    setbuff_Channel = 0                             #Channels assigned as prior, A = 0, B = 1, etc.
    setbuff_BuffMax = bufferAMax                    #Function output of buffer max data
    setbuff_BuffMin = bufferAMin                    #Function output of buffer min data
    setbuff_BuffLength = maxSamples                 #Calling previous variable
    setbuff_DownSamplingRatioMode = 0               #Related to Aggregate Mode. Set to 0 unless understood.
    
    status["setDataBuffersA"] = ps.ps6000SetDataBuffers(chandle, setbuff_Channel, ctypes.byref(setbuff_BuffMax), ctypes.byref(setbuff_BuffMin), setbuff_BuffLength, setbuff_DownSamplingRatioMode)
    
    assert_pico_ok(status["setDataBuffersA"])
    
    # Create overflow location, which tells us if any channels saturated
    
    
    #Loading data from PicoScope to the computer using ps6000getValues() function
    
    getdata_StartIndex = 0
    getdata_cmaxSamples = ctypes.c_int32(maxSamples)            # Convert maxSamples to a 32 bit integer for next function:
    getdata_DownSampleRatio = 1
    getdata_DownSampleRatioMode = 0
    getdata_SegmentationIndex = 0
    getdata_Overflow = ctypes.c_int16()                         # Create overflow location, which tells us if any channels saturated
    
    status["getValues"] = ps.ps6000GetValues(chandle, getdata_StartIndex, ctypes.byref(getdata_cmaxSamples), getdata_DownSampleRatio, getdata_DownSampleRatioMode, getdata_SegmentationIndex, ctypes.byref(getdata_Overflow))
    
    assert_pico_ok(status["getValues"])
    
    
    # Converting data to readable arrays
    
    #Find maximum ADC count value
    maxADC = ctypes.c_int16(32512)
    
    # Convert ADC counts data to mV
    adc2mVChAMax = adc2mV(bufferAMax, setch_Range, maxADC)
    
    # Create time data
    time = np.linspace(0, (getdata_cmaxSamples.value) * settimebase_ReturnedTimeInterval_ns.value, getdata_cmaxSamples.value)
    
    
    # Stop capture
     
    status["stop"] = ps.ps6000Stop(chandle)
    assert_pico_ok(status["stop"])
    
    
    print('Finished writing data.')

    # Plotting collected trace
    
    
    def my_plotter(ax, data1, data2, param_dict):
        """
        A helper function to make a graph
    
        Parameters
        ----------
        ax : Axes
            The axes to draw to
    
        data1 : array
           The x data
    
        data2 : array
           The y data
    
        param_dict : dict
           Dictionary of kwargs to pass to ax.plot
    
        Returns
        -------
        out : list
            list of artists added
        """
        out = ax.plot(data1, data2, **param_dict)
        return out
    
    # which you would then use as:
    
    data1 = time[0:1000]
    data2 = adc2mVChAMax[0:1000]
    fig, ax = plt.subplots(1, 1)
    my_plotter(ax, data1, data2, {'marker':''})
    
    
    # Integrating pulse voltage
    integratedVoltage = integrate.simps(data2,data1, even = 'last')
    # Writing into array
    pulseIntegrals[pulses,0] = integratedVoltage
    
    PulseIntegralsDataFile = open(PulseIntegralsFilename, "a")
    vIntDataString1 = "pulse %d \t " %pulses
    vIntDataString2 = "%f \n" %pulseIntegrals[pulses,0]
    vIntDataString = vIntDataString1 + vIntDataString2
    PulseIntegralsDataFile.write(vIntDataString)
    PulseIntegralsDataFile.close()
    
    
    
    timestamp = datetime.now()
    FilenameTimestamp = timestamp.strftime("%Y-%m-%d")

    
    str2="%s_"%FilenameTimestamp
    str3="%d"%pulses
    filestring = filename+str2+str3+".dat"
    
    voltageDataFile = open(filestring, "w")
    
    for i in adc2mVChAMax:        
        voltageDataFile.write("%f \n" %i)
        
    voltageDataFile.close()
    
    
    #peak = argrelmax(data2, order=5)
    
    pulses = pulses + 1
    
# Close scope with ps60000CloseUnit() function
ps.ps6000CloseUnit(chandle)    


print(status)
#print(peak)

#with open('python_streamed_PicoScope_square_wave_data_.dat', 'w+') as voltageDataFile:
#    for i in adc2mVChAMax:
#            voltageDataFile.write('%f \n' %i)